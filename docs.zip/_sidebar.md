<!-- docs/_sidebar.md -->

- 首页

  - [总述](home.md)

- 课程相关

  - [获取首页课程](course_home.md)
  - [获取全部课程](course_list.md)
  - [获取课程详细](course_detail.md)
  - [获取课程章节](course_section.md)
  - [获取课程评论](course_comment.md)
  - [感兴趣的课程](course_interest.md)

- 订单相关

  - [下单](order_add.md)
  - [订单查询](order_list.md)

- 工种相关

  - [获取全部工种](column_all.md)

- 用户相关
  - [登录](login.md)
  - [用户信息](user_detail.md)
